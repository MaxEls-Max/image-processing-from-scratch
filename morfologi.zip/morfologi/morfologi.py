import cv2
import numpy as np
import tkinter as tk
from PIL import Image, ImageTk
import glob


# =========================================================
# PENGATURAN
# =========================================================

BOX_WIDTH = 400
BOX_HEIGHT = 260

HEADER_HEIGHT = 45

ROW_GAP = 25


# =========================================================
# MENCARI FILE
# =========================================================

def cari_file(nama):

    ekstensi = [
        "*.png",
        "*.jpg",
        "*.jpeg",
        "*.bmp",
        "*.webp"
    ]

    for ext in ekstensi:

        hasil = glob.glob(nama + ext)

        if hasil:
            return hasil[0]

    return None


# =========================================================
# RESIZE TANPA MERUSAK RASIO
# =========================================================

def resize_keep_ratio(image, max_width, max_height):

    height, width = image.shape[:2]

    scale = min(
        max_width / width,
        max_height / height
    )

    new_width = int(width * scale)
    new_height = int(height * scale)

    return cv2.resize(
        image,
        (new_width, new_height),
        interpolation=cv2.INTER_AREA
    )


# =========================================================
# MEMBUAT PANEL
# =========================================================

def buat_panel(image, label):

    # Jika grayscale, ubah ke BGR
    if len(image.shape) == 2:

        image = cv2.cvtColor(
            image,
            cv2.COLOR_GRAY2BGR
        )

    # Resize
    image = resize_keep_ratio(
        image,
        BOX_WIDTH - 20,
        BOX_HEIGHT - 20
    )

    # Background hitam
    canvas = np.zeros(
        (BOX_HEIGHT, BOX_WIDTH, 3),
        dtype=np.uint8
    )

    h, w = image.shape[:2]

    x = (BOX_WIDTH - w) // 2
    y = (BOX_HEIGHT - h) // 2

    canvas[
        y:y+h,
        x:x+w
    ] = image

    # Header putih
    header = np.full(
        (HEADER_HEIGHT, BOX_WIDTH, 3),
        255,
        dtype=np.uint8
    )

    # Tulisan
    font = cv2.FONT_HERSHEY_SIMPLEX
    font_scale = 0.75
    thickness = 2

    text_size = cv2.getTextSize(
        label,
        font,
        font_scale,
        thickness
    )[0]

    text_x = (BOX_WIDTH - text_size[0]) // 2

    cv2.putText(
        header,
        label,
        (text_x, 30),
        font,
        font_scale,
        (0, 0, 0),
        thickness
    )

    return np.vstack((
        header,
        canvas
    ))


# =========================================================
# BINERISASI
# =========================================================

def buat_binary(img):

    if len(img.shape) == 3:

        gray = cv2.cvtColor(
            img,
            cv2.COLOR_BGR2GRAY
        )

    else:

        gray = img.copy()

    _, binary = cv2.threshold(
        gray,
        0,
        255,
        cv2.THRESH_BINARY + cv2.THRESH_OTSU
    )

    return binary


# =========================================================
# DILASI
# =========================================================

def proses_dilasi(binary):

    kernel = cv2.getStructuringElement(
        cv2.MORPH_RECT,
        (15, 15)
    )

    return cv2.dilate(
        binary,
        kernel,
        iterations=1
    )


# =========================================================
# OPENING
# =========================================================

def proses_opening(binary):

    kernel = cv2.getStructuringElement(
        cv2.MORPH_ELLIPSE,
        (7, 7)
    )

    return cv2.morphologyEx(
        binary,
        cv2.MORPH_OPEN,
        kernel,
        iterations=1
    )


# =========================================================
# THINNING
# =========================================================

def proses_thinning(binary):

    # Pastikan objek putih
    # dan background hitam

    if np.mean(binary) > 127:

        binary = cv2.bitwise_not(binary)

    if hasattr(cv2, "ximgproc"):

        return cv2.ximgproc.thinning(
            binary,
            thinningType=cv2.ximgproc.THINNING_ZHANGSUEN
        )

    else:

        print(
            "opencv-contrib-python belum terpasang."
        )

        print(
            "Install dengan:"
        )

        print(
            "pip install opencv-contrib-python"
        )

        return binary


# =========================================================
# EROSI
# =========================================================

def proses_erosi(binary):

    kernel = cv2.getStructuringElement(
        cv2.MORPH_ELLIPSE,
        (11, 11)
    )

    return cv2.erode(
        binary,
        kernel,
        iterations=1
    )


# =========================================================
# CLOSING
# =========================================================

def proses_closing(binary):

    kernel = cv2.getStructuringElement(
        cv2.MORPH_ELLIPSE,
        (3, 3)
    )

    return cv2.morphologyEx(
        binary,
        cv2.MORPH_CLOSE,
        kernel,
        iterations=1
    )


# =========================================================
# SKELETONIZATION
# =========================================================

def proses_skeletonization(binary):

    # Pastikan objek putih
    # dan background hitam

    if np.mean(binary) > 127:

        binary = cv2.bitwise_not(binary)

    binary = binary.copy()

    skeleton = np.zeros(
        binary.shape,
        dtype=np.uint8
    )

    kernel = cv2.getStructuringElement(
        cv2.MORPH_CROSS,
        (3, 3)
    )

    while True:

        eroded = cv2.erode(
            binary,
            kernel
        )

        opened = cv2.dilate(
            eroded,
            kernel
        )

        difference = cv2.subtract(
            binary,
            opened
        )

        skeleton = cv2.bitwise_or(
            skeleton,
            difference
        )

        binary = eroded.copy()

        if cv2.countNonZero(binary) == 0:

            break

    return skeleton


# =========================================================
# MEDIAN FILTER / PENGHILANGAN NOISE
# =========================================================

def proses_noise(img):

    return cv2.medianBlur(
        img,
        5
    )


# =========================================================
# DATA OPERASI MORFOLOGI
# =========================================================

data_morfologi = [

    (
        "angka_dilasi",
        "DILASI",
        proses_dilasi
    ),

    (
        "daun_opening",
        "OPENING",
        proses_opening
    ),

    (
        "huruf_thinning",
        "THINNING",
        proses_thinning
    ),

    (
        "koin_erosi",
        "EROSI",
        proses_erosi
    ),

    (
        "sidik_jari_closing",
        "CLOSING",
        proses_closing
    ),

    (
        "tulang_skeletonization",
        "SKELETONIZATION",
        proses_skeletonization
    )

]


# =========================================================
# PROSES DATA MORFOLOGI
# =========================================================

semua_baris = []


for nama_file, nama_operasi, fungsi in data_morfologi:

    path = cari_file(nama_file)

    if path is None:

        print(
            "File tidak ditemukan:",
            nama_file
        )

        continue


    # Baca citra
    img = cv2.imread(
        path,
        cv2.IMREAD_COLOR
    )

    if img is None:

        print(
            "Gagal membaca:",
            nama_file
        )

        continue


    # Biner
    binary = buat_binary(img)


    # Operasi morfologi
    hasil = fungsi(binary)


    # Panel kiri
    panel_kiri = buat_panel(
        img,
        "Citra"
    )


    # Panel kanan
    panel_kanan = buat_panel(
        hasil,
        "(" + nama_operasi + ")"
    )


    # Gabungkan kiri dan kanan
    baris = np.hstack((
        panel_kiri,
        panel_kanan
    ))

    semua_baris.append(baris)


# =========================================================
# PROSES NOISE
# =========================================================

path_noise = cari_file("noise")

if path_noise is not None:

    img_noise = cv2.imread(
        path_noise,
        cv2.IMREAD_COLOR
    )

    if img_noise is not None:

        hasil_noise = proses_noise(
            img_noise
        )

        # Panel kiri
        panel_noise_kiri = buat_panel(
            img_noise,
            "Citra"
        )

        # Panel kanan
        panel_noise_kanan = buat_panel(
            hasil_noise,
            "(Noise)"
        )

        # Gabungkan
        baris_noise = np.hstack((
            panel_noise_kiri,
            panel_noise_kanan
        ))

        semua_baris.append(
            baris_noise
        )

else:

    print(
        "File noise tidak ditemukan."
    )


# =========================================================
# CEK APAKAH ADA HASIL
# =========================================================

if len(semua_baris) == 0:

    print(
        "Tidak ada gambar yang berhasil diproses."
    )

    exit()


# =========================================================
# TKINTER
# =========================================================

root = tk.Tk()

root.title(
    "Operasi Morfologi dan Pengolahan Noise"
)

root.geometry(
    "850x700"
)


# =========================================================
# FRAME UTAMA
# =========================================================

frame_utama = tk.Frame(
    root
)

frame_utama.pack(
    fill="both",
    expand=True
)


# =========================================================
# CANVAS UNTUK SCROLL
# =========================================================

canvas = tk.Canvas(
    frame_utama,
    bg="gray"
)

canvas.pack(
    side="left",
    fill="both",
    expand=True
)


# =========================================================
# SCROLLBAR VERTIKAL
# =========================================================

scrollbar = tk.Scrollbar(
    frame_utama,
    orient="vertical",
    command=canvas.yview
)

scrollbar.pack(
    side="right",
    fill="y"
)

canvas.configure(
    yscrollcommand=scrollbar.set
)


# =========================================================
# FRAME DI DALAM CANVAS
# =========================================================

frame_gambar = tk.Frame(
    canvas,
    bg="gray"
)

canvas.create_window(
    (0, 0),
    window=frame_gambar,
    anchor="nw"
)


# =========================================================
# MASUKKAN SEMUA HASIL
# =========================================================

photo_images = []


for baris in semua_baris:

    # BGR → RGB
    rgb = cv2.cvtColor(
        baris,
        cv2.COLOR_BGR2RGB
    )

    # OpenCV → PIL
    pil_image = Image.fromarray(
        rgb
    )

    # PIL → Tkinter
    tk_image = ImageTk.PhotoImage(
        pil_image
    )

    photo_images.append(
        tk_image
    )

    label = tk.Label(
        frame_gambar,
        image=tk_image,
        bg="gray"
    )

    label.pack(
        pady=ROW_GAP // 2
    )


# =========================================================
# UPDATE AREA SCROLL
# =========================================================

def update_scroll_region(event):

    canvas.configure(
        scrollregion=canvas.bbox("all")
    )


frame_gambar.bind(
    "<Configure>",
    update_scroll_region
)


# =========================================================
# MOUSE WHEEL
# =========================================================

def scroll_mouse(event):

    canvas.yview_scroll(
        int(-1 * (event.delta / 120)),
        "units"
    )


canvas.bind_all(
    "<MouseWheel>",
    scroll_mouse
)


# =========================================================
# JALANKAN PROGRAM
# =========================================================

root.mainloop()